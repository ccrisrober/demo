#ifndef __VK__APPLICATION__
#define __VK__APPLICATION__

#define GLFW_INCLUDE_VULKAN
#include <GLFW/glfw3.h>

#include <iostream>
#include <stdexcept>
#include <functional>
#include <vector>
#include <cstring>

#include <assert.h>
#include <vector>
#include <string>

#include <algorithm>

static VkResult CreateDebugReportCallbackEXT( VkInstance instance,
  const VkDebugReportCallbackCreateInfoEXT* pCreateInfo,
  const VkAllocationCallbacks* pAllocator, VkDebugReportCallbackEXT* pCb )
{
  auto func = ( PFN_vkCreateDebugReportCallbackEXT ) vkGetInstanceProcAddr(
    instance, "vkCreateDebugReportCallbackEXT" );
  if ( func != nullptr )
  {
    return func( instance, pCreateInfo, pAllocator, pCb );
  }
  else {
    return VK_ERROR_EXTENSION_NOT_PRESENT;
  }
}

static void DestroyDebugReportCallbackEXT( VkInstance instance,
  VkDebugReportCallbackEXT callback, const VkAllocationCallbacks* pAllocator )
{
  auto func = ( PFN_vkDestroyDebugReportCallbackEXT ) vkGetInstanceProcAddr(
    instance, "vkDestroyDebugReportCallbackEXT" );
  if ( func != nullptr )
  {
    func( instance, callback, pAllocator );
  }
}

namespace vulcano
{

  class VKApplication {
  public:
    bool isValid( )
    {
      return _instance != VK_NULL_HANDLE;
    }
    const std::string name( ) const
    {
      return _info.pApplicationName;
    }
    const unsigned int version( ) const
    {
      return _info.applicationVersion;
    }
    const std::string engineName( ) const
    {
      return _info.pEngineName;
    }
    const unsigned int engineVersion( ) const
    {
      return _info.engineVersion;
    }
    const unsigned int apiVersion( ) const
    {
      return _info.apiVersion;
    }
    const unsigned int enableLayerCount( ) const
    {
      return static_cast<uint32_t>( _validationLayers.size( ) );
    }
    const unsigned int enableExtensionCount( ) const
    {
      return static_cast<uint32_t>( _extensions.size( ) );
    }
    const std::vector<std::string>& enableLayerNames( ) const
    {
      return _validationLayers;
    }
    const std::vector<std::string>& enableExtensionNames( ) const
    {
      return _extensions;
    }

    operator VkInstance( )
    {
      return _instance;
    }
  private:
    const int WIDTH = 800;
    const int HEIGHT = 600;

    VkInstance                          _instance;
    VkApplicationInfo                   _info;

    std::vector<std::string>            _validationLayers;
    std::vector<std::string>            _extensions;


#ifdef NDEBUG
    const bool enableValidationLayers = false;
#else
    const bool enableValidationLayers = true;
#endif

    GLFWwindow* window;

    VkDebugReportCallbackEXT            _debugReportCallback;
  public:
    VKApplication( )
      : _instance( VK_NULL_HANDLE )
      , _info( { } )
      , _validationLayers( { "VK_LAYER_LUNARG_standard_validation" } )
    {
      glfwInit( );

      glfwWindowHint( GLFW_CLIENT_API, GLFW_NO_API );
      glfwWindowHint( GLFW_RESIZABLE, GLFW_FALSE );

      window = glfwCreateWindow( WIDTH, HEIGHT, "Vulkan", nullptr, nullptr );
    }
    virtual ~VKApplication( )
    {
      if ( enableValidationLayers )
      {
        DestroyDebugReportCallbackEXT( _instance, VkDebugReportCallbackEXT { }, nullptr );
      }

      vkDestroyInstance( _instance, nullptr );
      //delete window;
    }
    bool initialize( void )
    {
      // Verify request VK instance layers are available
      if ( !CheckInstanceLayers( ) )
      {
        return false;
      }
      // Verify required exts layers are available
      if ( !CheckInstanceExtensions( ) )
      {
        return false;
      }

      _info.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
      _info.pNext = nullptr;
      _info.pApplicationName = "Test Name";
      _info.applicationVersion = VK_MAKE_VERSION( 1, 0, 0 );
      _info.pEngineName = "Engine Name";
      _info.engineVersion = VK_MAKE_VERSION( 1, 0, 0 );
      _info.apiVersion = VK_API_VERSION_1_0;

      _info.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
      _info.pNext = nullptr;
      _info.pApplicationName = "Test Name";
      _info.applicationVersion = VK_MAKE_VERSION( 1, 0, 0 );
      _info.pEngineName = "Engine Name";
      _info.engineVersion = VK_MAKE_VERSION( 1, 0, 0 );
      _info.apiVersion = VK_API_VERSION_1_0;


      VkInstanceCreateInfo createInfo;
      createInfo.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
      createInfo.pApplicationInfo = &_info;
      createInfo.pNext = nullptr;
      createInfo.flags = 0;

      std::vector<const char *> layers;
      if ( enableValidationLayers )
      {
        createInfo.enabledLayerCount = _validationLayers.size( );
        std::transform( _validationLayers.begin( ), _validationLayers.end( ),
          std::back_inserter( layers ), [] ( const std::string &s )
        {
          return s.c_str( );
        } );
        createInfo.ppEnabledLayerNames = layers.data( );
      }
      else
      {
        createInfo.enabledLayerCount = 0;
      }

      createInfo.enabledExtensionCount = _extensions.size( );
      std::vector<const char *> extensions;
      std::transform( _extensions.begin( ), _extensions.end( ),
        std::back_inserter( extensions ),
        [] ( const std::string &s )
      {
        return s.c_str( );
      } );
      createInfo.ppEnabledExtensionNames = extensions.data( );

      VkResult err = vkCreateInstance( &createInfo, nullptr, &_instance );

      if ( err != VK_SUCCESS ) {
        std::cerr << "VKApplication::initialize(): Failed to create instance!" << std::endl;
        return false;
      }

      if ( !SetupDebugCallback( ) )
      {
        return false;
      }

      return true;
    }

    bool SetupDebugCallback( void )
    {
      if ( !enableValidationLayers )
      {
        return true;
      }

      VkDebugReportCallbackCreateInfoEXT createInfo = { };
      createInfo.sType = VK_STRUCTURE_TYPE_DEBUG_REPORT_CALLBACK_CREATE_INFO_EXT;
      createInfo.flags = VK_DEBUG_REPORT_ERROR_BIT_EXT | VK_DEBUG_REPORT_WARNING_BIT_EXT;
      createInfo.pfnCallback = debugCallback;

      if ( CreateDebugReportCallbackEXT( _instance, &createInfo, nullptr,
        &_debugReportCallback ) != VK_SUCCESS )
      {
        throw std::runtime_error( "failed to set up debug callback!" );
      }
      return true;
    }

    static VKAPI_ATTR VkBool32 VKAPI_CALL debugCallback(
      VkDebugReportFlagsEXT flags, VkDebugReportObjectTypeEXT objType,
      uint64_t obj, size_t location, int32_t code, const char* layerPrefix,
      const char* msg, void* userData )
    {
      std::cerr << "validation layer: " << msg << std::endl;

      return VK_FALSE;
    }

    void run( ) {
      mainLoop( );
    }

    void mainLoop( ) {
      while ( !glfwWindowShouldClose( window ) )
      {
        glfwPollEvents( );
      }
      glfwDestroyWindow( window );
      glfwTerminate( );
    }

    bool CheckInstanceExtensions( )
    {
      VkResult err = VK_SUCCESS;

      // Surface extensions
      unsigned int glfwExtensionCount = 0;
      const char** glfwExtensions;
      glfwExtensions = glfwGetRequiredInstanceExtensions( &glfwExtensionCount );

      for ( unsigned int i = 0; i < glfwExtensionCount; i++ ) {
        _extensions.push_back( glfwExtensions[ i ] );
      }

      // Other extensions
      uint32_t instanceExtensionCount = 0;
      err = vkEnumerateInstanceExtensionProperties( nullptr, &instanceExtensionCount, nullptr );
      assert( !err );

      std::vector<VkExtensionProperties> instanceExtensions( instanceExtensionCount );
      err = vkEnumerateInstanceExtensionProperties( nullptr, &instanceExtensionCount, instanceExtensions.data( ) );
      assert( !err );

      for ( auto &ext : instanceExtensions ) {
        // Enable validation extension layer
        if ( !strcmp( VK_EXT_DEBUG_REPORT_EXTENSION_NAME, ext.extensionName ) )
          _extensions.push_back( VK_EXT_DEBUG_REPORT_EXTENSION_NAME );
      }

      return true;
    }

    bool CheckInstanceLayers( )
    {
      VkResult err;

      uint32_t layerCount;
      vkEnumerateInstanceLayerProperties( &layerCount, nullptr );

      std::vector<VkLayerProperties> availableLayers( layerCount );
      err = vkEnumerateInstanceLayerProperties( &layerCount, availableLayers.data( ) );
      assert( !err );

      for ( auto& layerName : _validationLayers )
      {
        bool layerFound = false;
        for ( auto& layerProperties : availableLayers )
        {
          if ( layerName == layerProperties.layerName )
          {
            layerFound = true;
            break;
          }
        }
        if ( !layerFound )
        {
          std::cerr << "VKApplication:CheckInstanceLayers() Cannot find layer " << layerName << std::endl;
          return false;
        }
      }
      return true;
    }
  };
}

#endif 