/***
#include <iostream>

#include "VKApplication.h"

int main( )
{
  VKApplication app;
  app.initialize( );
  return 0;
}
/**/
/***/
/**
#include "VKApplication.h"

namespace vulcano
{
  class VKDevice
  {
    struct QueueFamily
    {
      int graphics = -1;
      int compute = -1;

      bool isComplete( )
      {
        return graphics >= 0;
      }
    };
  public:
    VKDevice( )
      : _device( VK_NULL_HANDLE)
      , _physicalDevice( VK_NULL_HANDLE )
    {
    }
    ~VKDevice( )
    {
      vkDestroyDevice( _device, nullptr );
    }
    bool initialize( VKApplication& instance, uint32_t index )
    {


      VkResult err = VK_SUCCESS;


      VkDeviceCreateInfo devCI = { };
      devCI.sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;
      devCI.pNext = nullptr;
      devCI.queueCreateInfoCount = 1;
      devCI.pQueueCreateInfos = queueInfos.data( );
      devCI.pEnabledFeatures = &devFeatures;

      err = vkCreateDevice( _physicalDevice, &devCI, nullptr, &_device );
      if ( err != VK_SUCCESS )
      {
        throw std::runtime_error( "failed to create logical device!" );
      }

      return true;
    }
    operator VkDevice( void )
    {
      return _device;
    }
    operator VkPhysicalDevice( void )
    {
      return _physicalDevice;
    }
  private:
    bool enumeratePhysicalDevices( VKApplication& instance, uint32_t idx )
    {
      VkResult err = VK_SUCCESS;

      uint32_t deviceCount = 0;
      err = vkEnumeratePhysicalDevices( instance, &deviceCount, nullptr );
      assert( !err );

      if ( deviceCount == 0 )
      {
        throw std::runtime_error( "failed to find GPUs with Vulkan support!" );
      }

      std::vector<VkPhysicalDevice> devices( deviceCount );
      err = vkEnumeratePhysicalDevices( instance, &deviceCount, devices.data( ) );
      assert( !err );

      if ( deviceCount == 0 )
      {
        throw std::runtime_error( "VKDevice::enumeratePhysicalDevices() Vulkan encountered error enumerating devices." );
      }

      for ( const auto& device : devices ) {
        if ( isDeviceSuitable( device ) ) {
          _physicalDevice = device;
          break;
        }

      }
      if ( _physicalDevice == VK_NULL_HANDLE )
      {
        throw std::runtime_error( "failed to find a suitable GPU!" );
      }

      return true;
    }

    bool isDeviceSuitable( VkPhysicalDevice device ) {
      QueueFamily indices = findQueueFamilies( device );

      return indices.isComplete( );
    }

    QueueFamily findQueueFamilies( VkPhysicalDevice device ) {
      QueueFamily indices;

      uint32_t queueFamilyCount = 0;
      vkGetPhysicalDeviceQueueFamilyProperties( device, &queueFamilyCount, nullptr );

      _queueFamilyProperties = std::vector<VkQueueFamilyProperties>( queueFamilyCount );
      vkGetPhysicalDeviceQueueFamilyProperties( device, &queueFamilyCount, _queueFamilyProperties.data( ) );

      int i = 0;
      for ( const auto& queueFamily : _queueFamilyProperties )
      {
        if ( queueFamily.queueCount > 0 && queueFamily.queueFlags & VK_QUEUE_GRAPHICS_BIT ) {
          indices.graphics = i;
        }

        if ( indices.isComplete( ) ) {
          break;
        }

        i++;
      }

      return indices;
    }
    
    VkDevice                            _device;
    VkPhysicalDevice                    _physicalDevice;
    VkPhysicalDeviceFeatures            _physicalDeviceFeatures;
    VkPhysicalDeviceProperties          _physicalDeviceProperties;
    VkPhysicalDeviceMemoryProperties    _physicalDeviceMemoryProperties;

    std::vector<VkQueueFamilyProperties> _queueFamilyProperties;

    bool QueryPhysicalDeviceInfo( )
    {
      if ( _physicalDevice == VK_NULL_HANDLE )
        return false;

      vkGetPhysicalDeviceFeatures( _physicalDevice, &_physicalDeviceFeatures );
      vkGetPhysicalDeviceProperties( _physicalDevice, &_physicalDeviceProperties );
      vkGetPhysicalDeviceMemoryProperties( _physicalDevice, &_physicalDeviceMemoryProperties );


      return true;
    }

    QueueFamily QueryQueueFamily( VkQueueFlagBits flags )
    {
      QueueFamily family = { };

      // Find family index for graphics bit
      if ( flags & VK_QUEUE_GRAPHICS_BIT )
      {
        for ( uint32_t i = 0, l = _queueFamilyProperties.size( ); i < l; ++i )
        {
          if ( _queueFamilyProperties[ i ].queueFlags & flags )
          {
            family.graphics = i;
            break;
          }
        }
      }


      return family;
    }
  };
}

int main( ) {
  vulcano::VKApplication app;

  try {
    app.initialize( );

    vulcano::VKDevice device;
    device.initialize( app, 0 );

    //vulcano::VKSwapChain swapChain;
    //swapChain.initialize( app, device );

    app.run( );
  }
  catch ( const std::runtime_error& e ) {
    std::cerr << e.what( ) << std::endl;
    return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}
/**/

#define GLFW_INCLUDE_VULKAN
#include <GLFW/glfw3.h>
#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <assert.h>

// ==================================
// Layers and extensions
// ==================================

// This is the list of validation layers we want
const std::vector<const char*> VALIDATION_LAYERS = {
  "VK_LAYER_LUNARG_standard_validation",
};

VKAPI_ATTR VkBool32 VKAPI_CALL DebugCallbackFn(
  VkDebugReportFlagsEXT flags,
  VkDebugReportObjectTypeEXT objectType,
  uint64_t object,
  size_t location,
  int32_t messageCode,
  const char* pLayerPrefix,
  const char* pMessage,
  void* pUserData )
{
  std::cerr << pMessage << std::endl;
  return VK_FALSE;
}

VkResult CreateDebugReportCallbackEXT(
  VkInstance vkInstance,
  const VkDebugReportCallbackCreateInfoEXT* pCreateInfo,
  const VkAllocationCallbacks* pAllocator,
  VkDebugReportCallbackEXT* pCallback
)
{
  auto func = reinterpret_cast<PFN_vkCreateDebugReportCallbackEXT>( vkGetInstanceProcAddr( vkInstance, "vkCreateDebugReportCallbackEXT" ) );
  if ( func != nullptr ) {
    return func( vkInstance, pCreateInfo, pAllocator, pCallback );
  }
  else {
    return VK_ERROR_EXTENSION_NOT_PRESENT;
  }
}

void DestroyDebugReportCallbackEXT(
  VkInstance vkInstance,
  VkDebugReportCallbackEXT pCallback,
  const VkAllocationCallbacks* pAllocator
)
{
  auto func = reinterpret_cast<PFN_vkDestroyDebugReportCallbackEXT>( vkGetInstanceProcAddr( vkInstance, "vkDestroyDebugReportCallbackEXT" ) );
  if ( func != nullptr ) {
    func( vkInstance, pCallback, pAllocator );
  }
}

namespace vulcano
{
  class VulkanDevice
  {
  public:
    std::string m_name;
    VulkanDevice( GLFWwindow* window, std::string name )
      : m_name( name )
      //, surfaceKHR( nullptr )
    {
      Initialize( window );
    }
    ~VulkanDevice( )
    {
      Destroy( );
    }

    std::vector<const char*> GetInstanceRequiredExtensions( bool enableValidationLayers )
    {
      std::vector<const char*> extensions;

      uint32_t extensionCount = 0;
      const char** glfwExtensions;

      glfwExtensions = glfwGetRequiredInstanceExtensions( &extensionCount );

      for ( uint32_t i = 0; i < extensionCount; ++i )
      {
        extensions.push_back( glfwExtensions[ i ] );
      }

      if ( enableValidationLayers ) {
        extensions.push_back( VK_EXT_DEBUG_REPORT_EXTENSION_NAME );
      }

      return extensions;
    }

    bool CheckValidationLayerSupport( const std::vector<const char*>& validationLayers )
    {
      unsigned int layerCount = 0;
      vkEnumerateInstanceLayerProperties( &layerCount, nullptr );

      std::vector<VkLayerProperties> availalbeLayers( layerCount );
      vkEnumerateInstanceLayerProperties( &layerCount, availalbeLayers.data( ) );

      // Find the layer
      for ( auto layerName : validationLayers ) {
        bool foundLayer = false;
        for ( auto layerProperty : availalbeLayers ) {
          foundLayer = ( strcmp( layerName, layerProperty.layerName ) == 0 );
          if ( foundLayer ) {
            break;
          }
        }

        if ( !foundLayer ) {
          return false;
        }
      }
      return true;
    }

    VkResult InitializeVulkanInstance( ) {
      // Create application info struct
      VkApplicationInfo appInfo = { };
      appInfo.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
      appInfo.pApplicationName = m_name.c_str( );
      appInfo.applicationVersion = VK_MAKE_VERSION( 1, 0, 0 );
      appInfo.pEngineName = m_name.c_str( );
      appInfo.engineVersion = VK_MAKE_VERSION( 1, 0, 0 );
      appInfo.apiVersion = VK_API_VERSION_1_0;

      // Grab extensions. This includes the KHR surface extension and debug layer if in debug mode
      std::vector<const char*> extensions =
        GetInstanceRequiredExtensions( isEnableValidationLayers );

      // Create instance info struct
      VkInstanceCreateInfo instanceCreateInfo = { };
      instanceCreateInfo.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
      instanceCreateInfo.pNext = nullptr;
      instanceCreateInfo.pApplicationInfo = &appInfo;
      instanceCreateInfo.enabledExtensionCount = static_cast< uint32_t >( extensions.size( ) );
      instanceCreateInfo.ppEnabledExtensionNames = extensions.data( );

      // Grab validation layers
      if ( isEnableValidationLayers ) {
        assert( CheckValidationLayerSupport( VALIDATION_LAYERS ) );
        instanceCreateInfo.enabledLayerCount = static_cast< uint32_t >( VALIDATION_LAYERS.size( ) );
        instanceCreateInfo.ppEnabledLayerNames = VALIDATION_LAYERS.data( );
      }
      else {
        instanceCreateInfo.enabledLayerCount = 0;
      }

      return vkCreateInstance( &instanceCreateInfo, nullptr, &instance );
    }

    VkResult SetupDebugCallback( )
    {
      // Do nothing if we have not enabled debug mode
      if ( !isEnableValidationLayers ) {
        return VK_SUCCESS;
      }

      VkDebugReportCallbackCreateInfoEXT debugReportCallbackCreateInfo = { };
      debugReportCallbackCreateInfo.sType = VK_STRUCTURE_TYPE_DEBUG_REPORT_CALLBACK_CREATE_INFO_EXT;
      // Report errors and warnings back
      debugReportCallbackCreateInfo.flags = VK_DEBUG_REPORT_ERROR_BIT_EXT | VK_DEBUG_REPORT_WARNING_BIT_EXT;
      debugReportCallbackCreateInfo.pfnCallback = DebugCallbackFn;

      return CreateDebugReportCallbackEXT( instance, &debugReportCallbackCreateInfo, nullptr, &debugCallback );
    }

    std::vector<const char*> GetDeviceRequiredExtensions
      ( const VkPhysicalDevice& physicalDevice )
    {
      const std::vector<const char*> requiredExtensions = {
        VK_KHR_SWAPCHAIN_EXTENSION_NAME
      };

      uint32_t extensionCount = 0;
      vkEnumerateDeviceExtensionProperties( physicalDevice, nullptr, &extensionCount, nullptr );

      std::vector<VkExtensionProperties> availableExtensions( extensionCount );
      vkEnumerateDeviceExtensionProperties( physicalDevice, nullptr, &extensionCount, availableExtensions.data( ) );

      for ( auto& reqruiedExtension : requiredExtensions ) {
        if ( std::find_if( availableExtensions.begin( ), availableExtensions.end( ),
          [ &reqruiedExtension ] ( const VkExtensionProperties& prop ) {
          return strcmp( prop.extensionName, reqruiedExtension ) == 0;
        } ) == availableExtensions.end( ) ) {
          // Couldn't find this extension, return an empty list
          return { };
        }
      }

      return requiredExtensions;
    }

    struct QueueFamilyIndices {
      int graphicsFamily = -1;
      int presentFamily = -1;
      int computeFamily = -1;
      int transferFamily = -1;

      bool IsComplete( ) const {
        return graphicsFamily >= 0 && presentFamily >= 0 && computeFamily >= 0 && transferFamily >= 0;
      }
    };

    VulkanDevice::QueueFamilyIndices
      FindQueueFamilyIndices(
      const VkPhysicalDevice& physicalDevice
      , const VkSurfaceKHR& surfaceKHR )
    {
      VulkanDevice::QueueFamilyIndices queueFamilyIndices;

      uint32_t queueFamilyPropertyCount = 0;
      vkGetPhysicalDeviceQueueFamilyProperties( physicalDevice, &queueFamilyPropertyCount, nullptr );

      std::vector<VkQueueFamilyProperties> queueFamilyProperties( queueFamilyPropertyCount );
      vkGetPhysicalDeviceQueueFamilyProperties( physicalDevice, &queueFamilyPropertyCount, queueFamilyProperties.data( ) );

      int i = 0;
      for ( const auto& queueFamily : queueFamilyProperties ) {
        // We need at least one graphics queue
        if ( queueFamily.queueCount > 0 && queueFamily.queueFlags & VK_QUEUE_GRAPHICS_BIT ) {
          queueFamilyIndices.graphicsFamily = i;
        }

        // We need at least one queue that can present image to the KHR surface.
        // This could be a different queue from our graphics queue.
        // @todo: enforce graphics queue and present queue to be the same?
        VkBool32 presentationSupport = false;
        vkGetPhysicalDeviceSurfaceSupportKHR( physicalDevice, i, surfaceKHR, &presentationSupport );

        if ( queueFamily.queueCount > 0 && presentationSupport ) {
          queueFamilyIndices.presentFamily = i;
        }

        // Query compute queue family
        if ( queueFamily.queueCount > 0 && queueFamily.queueFlags & VK_QUEUE_COMPUTE_BIT ) {
          queueFamilyIndices.computeFamily = i;
        }

        // Query memory transfer family
        if ( queueFamily.queueCount > 0 && queueFamily.queueFlags & VK_QUEUE_TRANSFER_BIT ) {
          queueFamilyIndices.transferFamily = i;
        }

        if ( queueFamilyIndices.IsComplete( ) ) {
          break;
        }

        ++i;
      }

      return queueFamilyIndices;
    }

    bool IsDeviceVulkanCompatible( const VkPhysicalDevice& physicalDevice, 
      const VkSurfaceKHR& surfaceKHR )
    {
      // Can this physical device support all the extensions we'll need (ex. swap chain)
      std::vector<const char*> requiredExtensions = 
        GetDeviceRequiredExtensions( physicalDevice );
      bool hasAllRequiredExtensions = requiredExtensions.size( ) > 0;

      // Check if we have the device properties desired
      VkPhysicalDeviceProperties deviceProperties;
      vkGetPhysicalDeviceProperties( physicalDevice, &deviceProperties );
      bool isDiscreteGPU = deviceProperties.deviceType == VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU;

      // Query queue indices
      VulkanDevice::QueueFamilyIndices queueFamilyIndices = 
        FindQueueFamilyIndices( physicalDevice, surfaceKHR );

      // Query swapchain support
      //Swapchain::SwapchainSupport swapchainSupport = Swapchain::QuerySwapchainSupport( physicalDevice, surfaceKHR );

      return hasAllRequiredExtensions &&
        isDiscreteGPU &&
        //swapchainSupport.IsComplete( ) &&
        queueFamilyIndices.IsComplete( );
      return true;
    }
    VkResult CreateWindowSurface( GLFWwindow* window )
    {
      VkResult result = glfwCreateWindowSurface( instance, window, nullptr, &surfaceKHR );
      if ( result != VK_SUCCESS )
      {
        throw std::runtime_error( "Failed to create window surface" );
      }

      return result;
    }

    VkResult SelectPhysicalDevice( )
    {
      uint32_t physicalDeviceCount = 0;
      vkEnumeratePhysicalDevices( instance, &physicalDeviceCount, nullptr );

      if ( physicalDeviceCount == 0 ) {
        throw std::runtime_error( "Failed to find a GPU that supports Vulkan" );
      }

      std::vector<VkPhysicalDevice> physicalDevices( physicalDeviceCount );
      vkEnumeratePhysicalDevices( instance, &physicalDeviceCount, physicalDevices.data( ) );

      for ( auto pd : physicalDevices ) {
        if ( IsDeviceVulkanCompatible( pd, surfaceKHR ) ) {
          physicalDevice = pd;
          break;
        }
      }

      return physicalDevice != nullptr ? VK_SUCCESS : VK_ERROR_DEVICE_LOST;
    }
    VkResult SetupLogicalDevice( ) {
      // Create logical device info struct and populate it
      VkDeviceCreateInfo deviceCreateInfo = { };
      deviceCreateInfo.sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;

      VkPhysicalDeviceFeatures deviceFeatures = { };
      deviceFeatures.fillModeNonSolid = VK_TRUE;
      deviceCreateInfo.pEnabledFeatures = &deviceFeatures;

      // Create a set of unique queue families for the required queues
      queueFamilyIndices = FindQueueFamilyIndices( physicalDevice, surfaceKHR );
      std::vector<VkDeviceQueueCreateInfo> queueCreateInfos;
      std::set<int> uniqueQueueFamilies = { queueFamilyIndices.graphicsFamily, queueFamilyIndices.presentFamily, queueFamilyIndices.computeFamily };
      for ( auto familyIndex : uniqueQueueFamilies ) {
        VkDeviceQueueCreateInfo queueCreateInfo = { };
        queueCreateInfo.sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;
        queueCreateInfo.queueFamilyIndex = familyIndex;
        queueCreateInfo.queueCount = 1; // Only using one queue for now. We actually don't need that many.
        float queuePriority = 1.0f; // Queue priority. Required even if we only have one queue.
        queueCreateInfo.pQueuePriorities = &queuePriority;

        // Append to queue create infos
        queueCreateInfos.push_back( queueCreateInfo );
      }

      deviceCreateInfo.queueCreateInfoCount = static_cast< uint32_t >( queueCreateInfos.size( ) );
      deviceCreateInfo.pQueueCreateInfos = queueCreateInfos.data( );

      // Grab logical device extensions
      std::vector<const char*> enabledExtensions = GetDeviceRequiredExtensions( physicalDevice );
      deviceCreateInfo.enabledExtensionCount = static_cast< uint32_t >( enabledExtensions.size( ) );
      deviceCreateInfo.ppEnabledExtensionNames = enabledExtensions.data( );

      // Grab validation layers
      if ( isEnableValidationLayers ) {
        assert( CheckValidationLayerSupport( VALIDATION_LAYERS ) );
        deviceCreateInfo.enabledLayerCount = static_cast< uint32_t >( VALIDATION_LAYERS.size( ) );
        deviceCreateInfo.ppEnabledLayerNames = VALIDATION_LAYERS.data( );
      }
      else {
        deviceCreateInfo.enabledLayerCount = 0;
      }

      // Create the logical device
      VkResult result = vkCreateDevice( physicalDevice, &deviceCreateInfo, nullptr, &device );

      return result;
    }

    VkResult PrepareSwapchain( )
    {
      VkResult res;

      return res;
    }

    void Initialize( GLFWwindow* window )
    {
      VkResult res = InitializeVulkanInstance( );
      assert( res == VK_SUCCESS );
      std::cout << "Initalizes Vulkan instance" << std::endl;

      // Only enable the validation layer when running in debug mode
#ifdef NDEBUG
      isEnableValidationLayers = false;
#else
      isEnableValidationLayers = true;
#endif
      res = SetupDebugCallback( );
      assert( res == VK_SUCCESS );
      std::cout << "Setup debug callback" << std::endl;

      res = CreateWindowSurface( window );
      assert( res == VK_SUCCESS );
      std::cout << "Created window surface" << std::endl;

      res = SelectPhysicalDevice( );
      assert( res == VK_SUCCESS );
      std::cout << "Selected physical device" << std::endl;

      res = SetupLogicalDevice( );
      assert( res == VK_SUCCESS );
      std::cout << "Setup logical device" << std::endl;

      res = PrepareSwapchain( );
      assert( res == VK_SUCCESS );
      std::cout << "Created swapchain" << std::endl;
    }
    void Destroy( )
    {

    }
    // If enabled, will include the validation layer
    bool isEnableValidationLayers;
    // Callback fro the debug report in the Vulkan validation extension
    VkDebugReportCallbackEXT debugCallback;


    VkInstance instance;
    VkSurfaceKHR surfaceKHR;
    VkPhysicalDevice physicalDevice;
    VkDevice device;
    QueueFamilyIndices queueFamilyIndices;
  };
  class Scene
  {

  };
  class Renderer
  {
  public:
    Renderer(GLFWwindow* window, Scene* scene) 
      : m_window( window ), m_scene( scene )
    { }

    virtual ~Renderer( ) { }
    virtual void Update( ) = 0;
    virtual void Render( ) = 0;

  protected:
    GLFWwindow* m_window;
    Scene* m_scene;

    uint32_t m_width;
    uint32_t m_height;
  };

  class VulkanRenderer: public Renderer
  {
  public:
    VulkanDevice* m_vulkanDevice;
    VulkanRenderer(
      GLFWwindow* window,
      Scene* scene
      ) : Renderer( window, scene )
    {
      m_vulkanDevice = new VulkanDevice( m_window, "Vulkan Renderer" );
      //m_height = m_vulkanDevice->m_swapchain.extent.height;
      //m_width = m_vulkanDevice->m_swapchain.extent.width;
    }
    virtual ~VulkanRenderer( ) override
    {

    }

    virtual void Update( ) override
    {

    }

    virtual void Render( ) override
    {

    }
  };
}

int main( )
{
  glfwInit( );

  // Create window
  glfwWindowHint( GLFW_CLIENT_API, GLFW_NO_API );
  auto m_window = glfwCreateWindow( 500, 500, "Vulkan renderer", nullptr, nullptr );

  if ( !m_window )
  {
    glfwTerminate( );
    return -1;
  }
  vulcano::Scene* m_scene = new vulcano::Scene( );
  vulcano::Renderer* r = new vulcano::VulkanRenderer( m_window, m_scene );
  return 0;
}